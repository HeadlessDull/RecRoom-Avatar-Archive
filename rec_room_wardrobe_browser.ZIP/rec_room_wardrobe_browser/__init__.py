bl_info = {
    "name": "Rec Room Wardrobe Browser",
    "author": "Headless Dull",
    "version": (2, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Wardrobe",
    "description": "Browse and append wardrobe items from GitHub",
    "category": "Object",
}

import bpy
import bpy.utils.previews
import os
import json
import tempfile
import threading
import urllib.request
import urllib.error

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REPO          = "HeadlessDull/RecRoom-Avatar-Archive"
BRANCH        = "main"
RAW_BASE      = f"https://raw.githubusercontent.com/{REPO}/{BRANCH}"
API_BASE      = f"https://api.github.com/repos/{REPO}"
INDEX_PATH    = "index.json"   # repo-relative path to the index file

CATEGORIES = [
    "Belt", "Ear", "Eye", "Face", "Hair",
    "Hat", "Legs", "Neck", "Shirt", "Shoes",
    "Shoulder", "Wrist",
]

APPEND_MAP = {
    "FB": "FB Clothing",
    "MB": "MB Clothing",
}

ARMATURE_NAME = "Avatar_Skeleton"

# ---------------------------------------------------------------------------
# Addon Preferences  (PAT lives here — never in the scene or a .blend file)
# ---------------------------------------------------------------------------

class WardrobePreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    github_pat: bpy.props.StringProperty(
        name="GitHub PAT",
        description=(
            "Personal Access Token for private repo access. "
            "Leave blank once the repo is public."
        ),
        default="",
        subtype="PASSWORD",
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="GitHub Authentication:", icon="URL")
        layout.prop(self, "github_pat")
        layout.label(
            text="Generate at: GitHub → Settings → Developer settings → Tokens (classic)",
            icon="INFO",
        )


def _get_pat() -> str:
    prefs = bpy.context.preferences.addons.get(__name__)
    if prefs:
        return prefs.preferences.github_pat.strip()
    return ""


# ---------------------------------------------------------------------------
# Network helpers
# ---------------------------------------------------------------------------

def _make_request(url: str) -> urllib.request.Request:
    """Build a request with auth header if a PAT is set."""
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "RecRoomWardrobeBrowser/2.0")
    pat = _get_pat()
    if pat:
        req.add_header("Authorization", f"token {pat}")
    return req

def _fetch_bytes(url: str) -> bytes:
    """Fetch raw bytes from *url*. Raises urllib.error.URLError on failure."""
    req = _make_request(url)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read()

def _fetch_json(url: str) -> object:
    data = _fetch_bytes(url)
    return json.loads(data.decode("utf-8"))


# ---------------------------------------------------------------------------
# Cache directories
# ---------------------------------------------------------------------------

def _cache_dir() -> str:
    """Persistent cache folder next to the addon file."""
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    d = os.path.join(addon_dir, ".cache")
    os.makedirs(d, exist_ok=True)
    return d

def _preview_cache_path(repo_path: str) -> str:
    """Local path where a preview PNG is cached."""
    safe = repo_path.replace("/", "_").replace(" ", "_")
    return os.path.join(_cache_dir(), safe)

def _get_or_download_preview(repo_path: str) -> str:
    """Return local path to preview PNG, downloading if needed."""
    if not repo_path:
        return ""
    local = _preview_cache_path(repo_path)
    if os.path.isfile(local):
        return local
    try:
        url  = f"{RAW_BASE}/{urllib.parse.quote(repo_path)}"
        data = _fetch_bytes(url)
        with open(local, "wb") as f:
            f.write(data)
        return local
    except Exception:
        return ""


# urllib.parse isn't imported yet — add it
import urllib.parse


# ---------------------------------------------------------------------------
# Index / item cache
# ---------------------------------------------------------------------------

INDEX_CACHE: dict | None = None   # full parsed index.json
INDEX_ERROR: str         = ""     # last fetch error message
INDEX_LOADING: bool      = False  # background fetch in progress

def _load_index_background():
    """Fetch index.json in a background thread, then trigger a redraw."""
    global INDEX_CACHE, INDEX_ERROR, INDEX_LOADING
    INDEX_LOADING = True
    INDEX_ERROR   = ""
    try:
        url  = f"{RAW_BASE}/{INDEX_PATH}"
        data = _fetch_json(url)
        INDEX_CACHE = data
    except urllib.error.HTTPError as e:
        if e.code == 401:
            INDEX_ERROR = "Auth failed — check your PAT in addon preferences."
        elif e.code == 404:
            INDEX_ERROR = "index.json not found. Run build_index.py and commit it."
        else:
            INDEX_ERROR = f"HTTP {e.code}: {e.reason}"
    except Exception as e:
        INDEX_ERROR = str(e)
    finally:
        INDEX_LOADING = False
        # Ask Blender to redraw the panel from the main thread
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()

def fetch_index():
    """Kick off a background fetch of index.json if not already loaded."""
    global INDEX_LOADING
    if INDEX_CACHE is not None or INDEX_LOADING:
        return
    t = threading.Thread(target=_load_index_background, daemon=True)
    t.start()

def get_category_items(cat: str) -> list:
    if INDEX_CACHE is None:
        return []
    return INDEX_CACHE.get(cat, [])

def get_all_items() -> list:
    if INDEX_CACHE is None:
        return []
    result = []
    for cat in CATEGORIES:
        result.extend(INDEX_CACHE.get(cat, []))
    return result


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def _flatten(items: list) -> list:
    leaves = []
    for item in items:
        if item["children"]:
            leaves.extend(_flatten(item["children"]))
        elif item["blend"]:
            leaves.append(item)
    return leaves

def search_items(query: str) -> list:
    q = query.strip().lower()
    if not q:
        return []
    results = []
    for item in get_all_items():
        if item["children"]:
            matched = [c for c in item["children"] if q in c["label"].lower()]
            if matched:
                results.append({**item, "children": matched})
            elif q in item["label"].lower():
                results.append(item)
        elif item["blend"] and q in item["label"].lower():
            results.append(item)
    return results


# ---------------------------------------------------------------------------
# Preview helpers
# ---------------------------------------------------------------------------

PREVIEW_COLL = None

def _get_preview_coll():
    global PREVIEW_COLL
    if PREVIEW_COLL is None:
        PREVIEW_COLL = bpy.utils.previews.new()
    return PREVIEW_COLL

def load_preview(repo_path: str) -> int:
    """Return icon_id for a repo-relative PNG path."""
    if not repo_path:
        return 0
    local = _get_or_download_preview(repo_path)
    if not local or not os.path.isfile(local):
        return 0
    coll = _get_preview_coll()
    if local not in coll:
        try:
            coll.load(local, local, "IMAGE")
        except Exception:
            return 0
    return coll[local].icon_id


# ---------------------------------------------------------------------------
# Open-group state
# ---------------------------------------------------------------------------

def _open_set(context) -> set:
    raw = context.scene.wardrobe_open_groups
    return set(x for x in raw.split(",") if x)

def _set_open(context, key: str, value: bool):
    s = _open_set(context)
    if value:
        s.add(key)
    else:
        s.discard(key)
    context.scene.wardrobe_open_groups = ",".join(s)

def _safe_key(label: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in label).lower()


# ---------------------------------------------------------------------------
# Collection / armature helpers
# ---------------------------------------------------------------------------

def _collect_objects(col) -> list:
    objs = list(col.objects)
    for child in col.children:
        objs.extend(_collect_objects(child))
    return objs

def _remove_collection_recursive(col):
    for child in list(col.children):
        _remove_collection_recursive(child)
    for c in list(bpy.data.collections):
        if col.name in {x.name for x in c.children}:
            c.children.unlink(col)
    for scene in bpy.data.scenes:
        if col.name in {x.name for x in scene.collection.children}:
            scene.collection.children.unlink(col)
    bpy.data.collections.remove(col)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class WARDROBE_OT_fetch_index(bpy.types.Operator):
    bl_idname      = "wardrobe.fetch_index"
    bl_label       = "Fetch / Refresh Index"
    bl_description = "Download index.json from GitHub"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        global INDEX_CACHE, INDEX_ERROR
        INDEX_CACHE = None
        INDEX_ERROR = ""
        # Also clear preview cache so new thumbnails download fresh
        global PREVIEW_COLL
        if PREVIEW_COLL is not None:
            bpy.utils.previews.remove(PREVIEW_COLL)
            PREVIEW_COLL = None
        fetch_index()
        self.report({"INFO"}, "Fetching index from GitHub…")
        return {"FINISHED"}


class WARDROBE_OT_clear_preview_cache(bpy.types.Operator):
    bl_idname      = "wardrobe.clear_preview_cache"
    bl_label       = "Clear Preview Cache"
    bl_description = "Delete cached preview images so they re-download"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        global PREVIEW_COLL
        if PREVIEW_COLL is not None:
            bpy.utils.previews.remove(PREVIEW_COLL)
            PREVIEW_COLL = None
        cache = _cache_dir()
        removed = 0
        for f in os.listdir(cache):
            if f.lower().endswith(".png"):
                try:
                    os.remove(os.path.join(cache, f))
                    removed += 1
                except Exception:
                    pass
        self.report({"INFO"}, f"Cleared {removed} cached preview(s).")
        return {"FINISHED"}


class WARDROBE_OT_clear_search(bpy.types.Operator):
    bl_idname      = "wardrobe.clear_search"
    bl_label       = "Clear Search"
    bl_description = "Clear search and return to category view"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        context.scene.wardrobe_search = ""
        return {"FINISHED"}


class WARDROBE_OT_toggle_group(bpy.types.Operator):
    bl_idname      = "wardrobe.toggle_group"
    bl_label       = "Toggle Group"
    bl_description = "Expand / collapse variant group"
    bl_options     = {'REGISTER'}

    group_key: bpy.props.StringProperty()

    def execute(self, context):
        s     = _open_set(context)
        value = self.group_key not in s
        _set_open(context, self.group_key, value)
        return {"FINISHED"}


class WARDROBE_OT_select_item(bpy.types.Operator):
    bl_idname      = "wardrobe.select_item"
    bl_label       = "Select"
    bl_description = "Select this item ready to append"
    bl_options     = {'REGISTER'}

    blend_path: bpy.props.StringProperty()   # repo-relative path
    item_label: bpy.props.StringProperty()

    def execute(self, context):
        context.scene.wardrobe_selected_blend = self.blend_path
        context.scene.wardrobe_selected_label = self.item_label
        return {"FINISHED"}


class WARDROBE_OT_append_selected(bpy.types.Operator):
    bl_idname      = "wardrobe.append_selected"
    bl_label       = "Append to Scene"
    bl_description = "Download .blend and append FB/MB collections"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        repo_path = context.scene.wardrobe_selected_blend
        if not repo_path:
            self.report({"ERROR"}, "No item selected.")
            return {"CANCELLED"}

        warnings = []

        # ── 1. Check target collections ──────────────────────────────────
        missing = [v for v in APPEND_MAP.values() if v not in bpy.data.collections]
        if missing:
            warnings.append(f"Missing collections (using scene root): {', '.join(missing)}")

        # ── 2. Check Avatar_Skeleton ─────────────────────────────────────
        armature_obj = bpy.data.objects.get(ARMATURE_NAME)
        if armature_obj is None:
            warnings.append(f"'{ARMATURE_NAME}' not found — armature modifiers left unset.")

        # ── 3. Download .blend to a temp file ────────────────────────────
        url = f"{RAW_BASE}/{urllib.parse.quote(repo_path)}"
        tmp_path = ""
        try:
            self.report({"INFO"}, f"Downloading {os.path.basename(repo_path)}…")
            data = _fetch_bytes(url)
            with tempfile.NamedTemporaryFile(suffix=".blend", delete=False) as tmp:
                tmp.write(data)
                tmp_path = tmp.name
        except Exception as e:
            self.report({"ERROR"}, f"Download failed: {e}")
            return {"CANCELLED"}

        # ── 4. Append from temp file ─────────────────────────────────────
        try:
            with bpy.data.libraries.load(tmp_path, link=False) as (src, dst):
                targets = [c for c in src.collections if c in APPEND_MAP]
                if not targets:
                    self.report({"WARNING"}, "No FB or MB collections found in blend file.")
                    return {"CANCELLED"}
                dst.collections = targets

            moved_objects = []
            for wrapper in dst.collections:
                if wrapper is None:
                    continue
                target_name = APPEND_MAP.get(wrapper.name, "")
                target_col  = bpy.data.collections.get(target_name) if target_name else None
                if target_col is None:
                    target_col = context.scene.collection

                for obj in _collect_objects(wrapper):
                    if obj.name not in {o.name for o in target_col.objects}:
                        target_col.objects.link(obj)
                    if armature_obj and obj.type == 'MESH':
                        for mod in obj.modifiers:
                            if mod.type == 'ARMATURE' and mod.object is None:
                                mod.object = armature_obj
                    moved_objects.append(obj.name)

                _remove_collection_recursive(wrapper)

        finally:
            # ── 5. Always delete the temp file ───────────────────────────
            try:
                os.remove(tmp_path)
            except Exception:
                pass

        if not moved_objects:
            self.report({"WARNING"}, "No objects found in FB/MB collections.")
            return {"CANCELLED"}

        # ── 6. Clean undo push ───────────────────────────────────────────
        bpy.ops.ed.undo_push(message=f"Append {context.scene.wardrobe_selected_label}")

        # ── 7. Report ────────────────────────────────────────────────────
        msg = f"Added {len(moved_objects)} object(s)"
        if armature_obj:
            msg += f" | Wired to {ARMATURE_NAME}"
        self.report({"INFO"}, msg)
        for w in warnings:
            self.report({"WARNING"}, w)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class WARDROBE_PT_main(bpy.types.Panel):
    bl_label       = "Rec Room Wardrobe"
    bl_idname      = "WARDROBE_PT_main"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "Wardrobe"

    def draw(self, context):
        layout = self.layout
        scene  = context.scene

        # ── Index status / fetch button ───────────────────────────────────
        box = layout.box()
        row = box.row(align=True)

        if INDEX_LOADING:
            row.label(text="Loading index…", icon="TIME")
        elif INDEX_ERROR:
            row.alert = True
            row.label(text=INDEX_ERROR, icon="ERROR")
            row.alert = False
            box.operator("wardrobe.fetch_index", text="Retry", icon="FILE_REFRESH")
            return
        elif INDEX_CACHE is None:
            row.label(text="Index not loaded", icon="QUESTION")
            box.operator("wardrobe.fetch_index", text="Load from GitHub", icon="URL")
            # Kick off auto-fetch
            fetch_index()
            return
        else:
            row.label(text="Index loaded ✓", icon="CHECKMARK")
            row.operator("wardrobe.fetch_index", text="", icon="FILE_REFRESH")

        layout.separator()

        # ── Scene status ─────────────────────────────────────────────────
        status = layout.box()
        status.label(text="Scene Status:", icon="OUTLINER_COLLECTION")
        row = status.row(align=True)
        for col_name in APPEND_MAP.values():
            exists = col_name in bpy.data.collections
            sub    = row.row()
            sub.alert = not exists
            sub.label(text=col_name, icon="CHECKMARK" if exists else "X")
        arm_row = status.row()
        arm_exists = ARMATURE_NAME in bpy.data.objects
        arm_row.alert = not arm_exists
        arm_row.label(
            text=ARMATURE_NAME,
            icon="ARMATURE_DATA" if arm_exists else "ERROR",
        )

        layout.separator()

        # ── Search ───────────────────────────────────────────────────────
        search_query = scene.wardrobe_search.strip()
        row = layout.row(align=True)
        row.prop(scene, "wardrobe_search", text="", icon="VIEWZOOM")
        if search_query:
            row.operator("wardrobe.clear_search", text="", icon="X")

        layout.separator()

        # ── Gallery ──────────────────────────────────────────────────────
        open_groups    = _open_set(context)
        selected_blend = scene.wardrobe_selected_blend

        if search_query:
            results = search_items(search_query)
            if not results:
                layout.label(text=f'No results for "{search_query}"', icon="INFO")
            else:
                layout.label(text=f"{len(_flatten(results))} result(s):", icon="VIEWZOOM")
                for item in results:
                    self._draw_item(layout, item, open_groups, selected_blend)
        else:
            layout.label(text="Category:", icon="DOWNARROW_HLT")
            layout.prop(scene, "wardrobe_category", text="")
            layout.separator()
            items = get_category_items(scene.wardrobe_category)
            if not items:
                layout.label(text="No items in this category.", icon="INFO")
            else:
                for item in items:
                    self._draw_item(layout, item, open_groups, selected_blend)

        # ── Append bar ────────────────────────────────────────────────────
        if selected_blend:
            layout.separator()
            bar = layout.box()
            bar.label(text=scene.wardrobe_selected_label, icon="CHECKMARK")
            bar.operator("wardrobe.append_selected", icon="IMPORT")

    # ── Draw helpers ─────────────────────────────────────────────────────

    def _draw_item(self, layout, item, open_groups, selected_blend):
        if item["children"]:
            self._draw_group(layout, item, open_groups, selected_blend)
        elif item["blend"]:
            self._draw_leaf(layout, item, selected_blend)

    def _draw_group(self, layout, item, open_groups, selected_blend):
        key     = _safe_key(item["label"])
        is_open = key in open_groups
        box     = layout.box()

        row  = box.row(align=True)
        icon = "TRIA_DOWN" if is_open else "TRIA_RIGHT"
        op   = row.operator("wardrobe.toggle_group",
                            text=item["label"], icon=icon, emboss=False)
        op.group_key = key

        # Preview always visible
        if item["preview"]:
            ico = load_preview(item["preview"])
            if ico:
                box.template_icon(icon_value=ico, scale=5.0)

        if is_open:
            for child in item["children"]:
                self._draw_leaf(box, child, selected_blend)

    def _draw_leaf(self, layout, item, selected_blend):
        is_sel = item["blend"] == selected_blend
        box    = layout.box()
        if is_sel:
            box.alert = True

        row = box.row(align=True)
        ico = load_preview(item["preview"])
        if ico:
            row.template_icon(icon_value=ico, scale=4.0)
        else:
            row.label(icon="IMAGE_DATA", text="")

        col = row.column(align=True)
        col.label(text=item["label"])
        op = col.operator(
            "wardrobe.select_item",
            text="Selected ✓" if is_sel else "Select",
            icon="RADIOBUT_ON" if is_sel else "RADIOBUT_OFF",
            depress=is_sel,
        )
        op.blend_path = item["blend"]
        op.item_label = item["label"]


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = [
    WardrobePreferences,
    WARDROBE_OT_fetch_index,
    WARDROBE_OT_clear_preview_cache,
    WARDROBE_OT_clear_search,
    WARDROBE_OT_toggle_group,
    WARDROBE_OT_select_item,
    WARDROBE_OT_append_selected,
    WARDROBE_PT_main,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.wardrobe_category = bpy.props.EnumProperty(
        name="Category",
        items=[(c, c, "") for c in CATEGORIES],
    )
    bpy.types.Scene.wardrobe_search = bpy.props.StringProperty(
        name="Search", default="")
    bpy.types.Scene.wardrobe_selected_blend = bpy.props.StringProperty(
        name="Selected Blend", default="")
    bpy.types.Scene.wardrobe_selected_label = bpy.props.StringProperty(
        name="Selected Label", default="")
    bpy.types.Scene.wardrobe_open_groups = bpy.props.StringProperty(
        name="Open Groups", default="")


def unregister():
    global PREVIEW_COLL, INDEX_CACHE, INDEX_ERROR, INDEX_LOADING
    INDEX_CACHE    = None
    INDEX_ERROR    = ""
    INDEX_LOADING  = False
    if PREVIEW_COLL is not None:
        bpy.utils.previews.remove(PREVIEW_COLL)
        PREVIEW_COLL = None

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    for attr in ["wardrobe_category", "wardrobe_search",
                 "wardrobe_selected_blend", "wardrobe_selected_label",
                 "wardrobe_open_groups"]:
        try:
            delattr(bpy.types.Scene, attr)
        except Exception:
            pass


if __name__ == "__main__":
    register()
