bl_info = {
    "name": "Rec Room Wardrobe Browser",
    "author": "Headless Dull",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Wardrobe",
    "description": "Browse and append rec room wardrobe items",
    "category": "Object",
}

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------

import bpy, bpy.utils.previews
import os, json, tempfile, threading, hashlib
import urllib.request, urllib.error, urllib.parse
import importlib as _importlib, sys as _sys

# ---------------------------------------------------------------------------
# Rig UI
# ---------------------------------------------------------------------------

def _load_rig_ui():
    mod_path = os.path.join(os.path.dirname(__file__), "rig_ui_patch.py")
    spec = _importlib.util.spec_from_file_location("rig_ui_patch", mod_path)
    mod  = _importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _sys.modules["rig_ui_patch"] = mod
    mod.register_rig_ui()

def _unload_rig_ui():
    mod = _sys.modules.get("rig_ui_patch")
    if mod:
        try: mod.unregister_rig_ui()
        except: pass
        _sys.modules.pop("rig_ui_patch", None)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

REPO          = "HeadlessDull/RecRoom-Avatar-Archive"
RAW_BASE      = f"https://raw.githubusercontent.com/{REPO}/main"
CATEGORIES    = ["Belt","Ear","Eye","Face","Hair","Hat","Legs","Neck","Shirt","Shoes","Shoulder","Wrist"]
APPEND_MAP    = {"FB": "FB Clothing", "MB": "MB Clothing"}
ARMATURE      = "Avatar_Skeleton"
RIG_FILE      = os.path.join(os.path.dirname(__file__), "Rec_Room_Rig.blend")
RIG_COL       = "Rec Room Rig"
RIG_UI_SCRIPT = "Avatar_RigUI.py"
CLOTHING_COLS    = {"FB": "FB Clothing", "MB": "MB Clothing"}
UNITY_RIG_FILE   = os.path.join(os.path.dirname(__file__), "Rec_Room_Unity_Rig.blend")
UNITY_RIG_COL    = "Rec Room Unity Rig"
UNITY_ARMATURE   = "Avatar Skeleton"
BAKE_COL_NAME    = "Bake"
BAKE_RES         = 1024
# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

INDEX_CACHE   = None
INDEX_ERROR   = ""
INDEX_LOADING = False
PREVIEW_COLL  = None

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _pat():
    a = bpy.context.preferences.addons.get(__name__)
    return a.preferences.github_pat.strip() if a else ""

def _fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "RRWardrobeBrowser"})
    if p := _pat(): req.add_header("Authorization", f"token {p}")
    with urllib.request.urlopen(req, timeout=30) as r: return r.read()

def _cache_dir():
    d = os.path.join(os.path.dirname(__file__), ".cache")
    os.makedirs(d, exist_ok=True)
    return d

def _preview_local(repo_path):
    return os.path.join(_cache_dir(), hashlib.md5(repo_path.encode()).hexdigest() + ".png")

def _download_preview(repo_path):
    if not repo_path: return
    local = _preview_local(repo_path)
    if os.path.isfile(local): return
    try:
        data = _fetch(f"{RAW_BASE}/{urllib.parse.quote(repo_path, safe='/').replace('(', '%28').replace(')', '%29')}")
        open(local, "wb").write(data)
    except Exception as e:
        print(f"Preview download failed: {repo_path} — {e}")

# Maps local_path -> icon_id (0 = pending/failed, >0 = ready)
_PREVIEW_ICONS = {}
# Set of repo_paths currently being fetched
_FETCHING = set()
# Semaphore to limit concurrent downloads
_DOWNLOAD_SEMAPHORE = threading.Semaphore(5)
# Sentinel for timed-out/missing
MISSING_ICON = 0

def _load_icon(local):
    """Load a PNG into PREVIEW_COLL and return its icon_id. Call on main thread only."""
    global PREVIEW_COLL
    if PREVIEW_COLL is None: PREVIEW_COLL = bpy.utils.previews.new()
    if local in PREVIEW_COLL:
        ico = PREVIEW_COLL[local].icon_id
        if ico != 0: return ico
        try: del PREVIEW_COLL[local]
        except: pass
    try:
        PREVIEW_COLL.load(local, local, "IMAGE")
        return PREVIEW_COLL[local].icon_id
    except:
        return 0

def _watch_and_load(repo_path, local):
    """Background thread: wait up to 10s for file to appear, then load icon via timer."""
    import time
    deadline = time.time() + 10.0
    while time.time() < deadline:
        if os.path.isfile(local):
            def _do_load(l=local, p=repo_path):
                ico = _load_icon(l)
                _PREVIEW_ICONS[l] = ico if ico != 0 else -1
                _redraw_all()
                return None
            bpy.app.timers.register(_do_load, first_interval=0.05)
            return
        time.sleep(0.2)
    # Timed out
    _PREVIEW_ICONS[local] = -1  # -1 = missing

def load_preview(repo_path):
    """Return icon_id for a preview. Kicks off download+watch if not started yet."""
    if not repo_path: return 0
    local = _preview_local(repo_path)
    # Already resolved
    if local in _PREVIEW_ICONS:
        ico = _PREVIEW_ICONS[local]
        return ico if ico > 0 else 0
    # File on disk but not loaded yet
    if os.path.isfile(local):
        ico = _load_icon(local)
        _PREVIEW_ICONS[local] = ico if ico != 0 else 0
        return ico
    # Not started yet — kick off download + watch
    if repo_path not in _FETCHING:
        _FETCHING.add(repo_path)
        def _fetch_and_watch(rp=repo_path, lp=local):
            with _DOWNLOAD_SEMAPHORE:
                _download_preview(rp)
            _watch_and_load(rp, lp)
        threading.Thread(target=_fetch_and_watch, daemon=True).start()
    return 0

def _reset_previews():
    """Clear all preview state. Call when index refreshes or cache clears."""
    global PREVIEW_COLL, _DOWNLOAD_SEMAPHORE
    _PREVIEW_ICONS.clear()
    _FETCHING.clear()
    _DOWNLOAD_SEMAPHORE = threading.Semaphore(5)
    if PREVIEW_COLL:
        bpy.utils.previews.remove(PREVIEW_COLL)
        PREVIEW_COLL = None

def _preload_cached_previews():
    """Load any already-cached PNGs into icons dict immediately."""
    cache = _cache_dir()
    if not os.path.isdir(cache): return None
    for fname in os.listdir(cache):
        if not fname.lower().endswith(".png"): continue
        local = os.path.join(cache, fname)
        if local not in _PREVIEW_ICONS:
            ico = _load_icon(local)
            _PREVIEW_ICONS[local] = ico if ico != 0 else 0
    bpy.app.timers.register(_redraw_all, first_interval=0.3)
    return None
def _load_index_bg():
    global INDEX_CACHE, INDEX_ERROR, INDEX_LOADING
    try:
        INDEX_CACHE = json.loads(_fetch(f"{RAW_BASE}/index.json"))
        bpy.app.timers.register(_preload_cached_previews, first_interval=0.2)
    except urllib.error.HTTPError as e:
        INDEX_ERROR = ("Auth failed — check PAT in preferences." if e.code == 401 else
                       "index.json not found — run build_index.py." if e.code == 404 else
                       f"HTTP {e.code}: {e.reason}")
    except Exception as e:
        INDEX_ERROR = str(e)
    finally:
        INDEX_LOADING = False
        bpy.app.timers.register(lambda: _redraw_all() or None, first_interval=0.05)

def _preload_cached_previews():
    """Load all cached PNGs into PREVIEW_COLL, then redraw."""
    global PREVIEW_COLL
    if PREVIEW_COLL is None: PREVIEW_COLL = bpy.utils.previews.new()
    cache = _cache_dir()
    if not os.path.isdir(cache): return None
    for fname in os.listdir(cache):
        if not fname.lower().endswith(".png"): continue
        local = os.path.join(cache, fname)
        if local in PREVIEW_COLL: continue
        try: PREVIEW_COLL.load(local, local, "IMAGE")
        except: pass
    # Redraw after a short delay to let GPU finish texture upload
    bpy.app.timers.register(_redraw_all, first_interval=0.3)
    return None


def fetch_index():
    global INDEX_LOADING
    if INDEX_CACHE or INDEX_LOADING: return
    INDEX_LOADING = True
    threading.Thread(target=_load_index_bg, daemon=True).start()

def all_items():
    if not INDEX_CACHE: return []
    return [i for cat in CATEGORIES for i in INDEX_CACHE.get(cat, [])]

def search_items(q):
    q = q.lower()
    out = []
    for item in all_items():
        if item["children"]:
            matched = [c for c in item["children"] if q in c["label"].lower()]
            out.append({**item, "children": matched} if matched
                       else item if q in item["label"].lower() else None)
        elif item["blend"] and q in item["label"].lower():
            out.append(item)
    return [x for x in out if x]

def flatten(items):
    return [i for item in items
            for i in (flatten(item["children"]) if item["children"] else [item] if item["blend"] else [])]

def _open_set(ctx):
    return set(x for x in ctx.scene.wardrobe_open_groups.split(",") if x)

def _toggle_open(ctx, key):
    s = _open_set(ctx)
    s.discard(key) if key in s else s.add(key)
    ctx.scene.wardrobe_open_groups = ",".join(s)

def _safe_key(label):
    return "".join(c if c.isalnum() else "_" for c in label).lower()

def _collect_objects(col):
    return list(col.objects) + [o for c in col.children for o in _collect_objects(c)]

def _remove_col(col):
    for c in list(col.children): _remove_col(c)
    for c in list(bpy.data.collections):
        if col.name in {x.name for x in c.children}: c.children.unlink(col)
    for s in bpy.data.scenes:
        if col.name in {x.name for x in s.collection.children}: s.collection.children.unlink(col)
    bpy.data.collections.remove(col)

def _base(name):
    parts = name.rsplit(".", 1)
    return parts[0] if len(parts) == 2 and parts[1].isdigit() else name

def _all_children(col):
    for c in col.children:
        yield c
        yield from _all_children(c)

def _rig_in_scene():
    for c in bpy.data.collections:
        if (_base(c.name) == RIG_COL and
                any(c.name in {x.name for x in s.collection.children}
                    for s in bpy.data.scenes)):
            return c
    return None

def _check_rig(col):
    if not col: return False, [RIG_COL]
    child_base_names = {_base(c.name) for c in _all_children(col)}
    missing = [req for req in CLOTHING_COLS.values() if req not in child_base_names]
    if ARMATURE not in {_base(o.name) for o in _collect_objects(col)}: missing.append(ARMATURE)
    return len(missing) == 0, missing

# ---------------------------------------------------------------------------
# Export helpers
# ---------------------------------------------------------------------------

def _get_source_objects(body_type):
    col_name = "BeanBody" if body_type == "MB" else "FullBody"
    objs = []
    col = bpy.data.collections.get(col_name)
    if col:
        objs += [o for o in _collect_objects(col) if o.type == "MESH"]
    avatar_meshes = bpy.data.objects.get("Avatar_Meshes")
    if avatar_meshes:
        for child in avatar_meshes.children:
            if child.name in AVATAR_MESH_SKIP:
                continue
            if child.type == "MESH":
                objs.append(child)
            for grandchild in child.children_recursive:
                if grandchild.type == "MESH":
                    objs.append(grandchild)
    seen = set(); result = []
    for o in objs:
        if o.name not in seen:
            seen.add(o.name); result.append(o)
    return result

def _ensure_bake_collection(context):
    col = bpy.data.collections.get(BAKE_COL_NAME)
    if not col:
        col = bpy.data.collections.new(BAKE_COL_NAME)
        context.scene.collection.children.link(col)
    return col

def _duplicate_for_bake(orig, bake_col, context):
    new_obj = orig.copy()
    new_obj.data = orig.data.copy()
    new_obj.name = orig.name + "_bake"
    bake_col.objects.link(new_obj)
    new_obj.data.materials.clear()
    for mat in orig.data.materials:
        new_obj.data.materials.append(mat.copy() if mat else None)
    if new_obj.data.materials:
        for i, mat in enumerate(new_obj.data.materials):
            if mat: mat.name = mat.name if mat.name.endswith("_bake") else mat.name + "_bake"
    arm_targets = [m.object for m in new_obj.modifiers if m.type == "ARMATURE" and m.object]
    context.view_layer.objects.active = new_obj
    new_obj.select_set(True)
    for mod in list(new_obj.modifiers):
        if mod.type != "ARMATURE":
            try: bpy.ops.object.modifier_apply(modifier=mod.name)
            except: new_obj.modifiers.remove(mod)
    for mod in list(new_obj.modifiers):
        if mod.type == "ARMATURE": new_obj.modifiers.remove(mod)
    new_obj.select_set(False)
    return new_obj, arm_targets


def _add_bake_image_node(mat, img):
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    for n in [n for n in nodes if n.name == "BAKE_TARGET"]: nodes.remove(n)
    node = nodes.new("ShaderNodeTexImage")
    node.name = "BAKE_TARGET"; node.image = img
    for n in nodes: n.select = False
    node.select = True; nodes.active = node

def _cleanup_bake(bake_col):
    if not bake_col: return
    objs   = list(_collect_objects(bake_col))
    meshes = [o.data for o in objs if o.type == "MESH" and o.data]
    mats   = list({m for o in objs if o.type == "MESH"
                   for m in o.data.materials if m and "_bake" in m.name})
    images = [i for i in bpy.data.images if "_bake" in i.name]
    for obj in objs:
        for col in list(bpy.data.collections):
            if obj.name in {o.name for o in col.objects}: col.objects.unlink(obj)
        bpy.data.objects.remove(obj, do_unlink=True)
    for m in meshes:
        if m.users == 0: bpy.data.meshes.remove(m)
    for m in mats:
        if m.users == 0: bpy.data.materials.remove(m)
    for i in images: bpy.data.images.remove(i)
    _remove_col(bake_col)


# ---------------------------------------------------------------------------
# Preferences
# ---------------------------------------------------------------------------

class WardrobePreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    github_pat: bpy.props.StringProperty(name="GitHub PAT", default="", subtype="PASSWORD",
        description="Token for private repo — leave blank when repo is public")
    def draw(self, context):
        self.layout.prop(self, "github_pat")
        self.layout.label(text="Developer Setting", icon="INFO")


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class WARDROBE_OT_clear_cache(bpy.types.Operator):
    bl_idname = "wardrobe.clear_cache"; bl_label = "Clear Preview Cache"
    bl_description = "Delete all cached preview images so they re-download"; bl_options = {"REGISTER"}
    def execute(self, context):
        global PREVIEW_COLL
        _reset_previews()
        cache = _cache_dir()
        removed = 0
        if os.path.isdir(cache):
            for f in os.listdir(cache):
                if f.lower().endswith(".png"):
                    try: os.remove(os.path.join(cache, f)); removed += 1
                    except: pass
        self.report({"INFO"}, f"Cleared {removed} cached preview(s).")
        return {"FINISHED"}


class WARDROBE_OT_enable(bpy.types.Operator):
    bl_idname = "wardrobe.enable"; bl_label = "Enable Wardrobe Browser"
    bl_description = "Enable the wardrobe browser"; bl_options = {'REGISTER'}
    def execute(self, context):
        context.scene.wardrobe_enabled = True
        fetch_index()
        return {"FINISHED"}


class WARDROBE_OT_append_rig(bpy.types.Operator):
    bl_idname = "wardrobe.append_rig"; bl_label = "Set Up Scene"
    bl_description = "Append the Rec Room Rig and set colour management to Standard"; bl_options = {'REGISTER'}
    def execute(self, context):
        if not os.path.isfile(RIG_FILE):
            self.report({"ERROR"}, "Rec_Room_Rig.blend not found inside addon folder.")
            return {"CANCELLED"}
        view_settings = context.scene.view_settings
        if view_settings.view_transform != "Standard":
            view_settings.view_transform = "Standard"
            self.report({"INFO"}, "Colour management set to Standard.")
        with bpy.data.libraries.load(RIG_FILE, link=False) as (data_from, data_to):
            if RIG_COL not in data_from.collections:
                self.report({"ERROR"}, f"'{RIG_COL}' not found in rig blend.")
                return {"CANCELLED"}
            data_to.collections = [RIG_COL]
            data_to.texts = [t for t in data_from.texts if t == RIG_UI_SCRIPT]
        appended_col = None
        for col in data_to.collections:
            if col is None: continue
            if col.name not in {c.name for c in context.scene.collection.children}:
                context.scene.collection.children.link(col)
            appended_col = col
        try:
            _load_rig_ui()
        except Exception as e:
            self.report({"WARNING"}, f"Rig UI load warning: {e}")
        bpy.ops.ed.undo_push(message="Set Up Scene")
        self.report({"INFO"}, f"Scene set up: {appended_col.name if appended_col else RIG_COL}")
        return {"FINISHED"}


class WARDROBE_OT_fetch_index(bpy.types.Operator):
    bl_idname = "wardrobe.fetch_index"; bl_label = "Refresh Index"
    bl_description = "Re-download index.json from GitHub"; bl_options = {'REGISTER'}
    def execute(self, context):
        global INDEX_CACHE, INDEX_ERROR, PREVIEW_COLL
        INDEX_CACHE = None; INDEX_ERROR = ""
        _reset_previews()
        fetch_index()
        bpy.app.timers.register(_preload_cached_previews, first_interval=0.5)
        self.report({"INFO"}, "Fetching index…"); return {"FINISHED"}


class WARDROBE_OT_clear_search(bpy.types.Operator):
    bl_idname = "wardrobe.clear_search"; bl_label = "Clear Search"; bl_options = {'REGISTER'}
    def execute(self, context):
        context.scene.wardrobe_search = ""; return {"FINISHED"}


class WARDROBE_OT_toggle_group(bpy.types.Operator):
    bl_idname = "wardrobe.toggle_group"; bl_label = "Toggle Group"; bl_options = {'REGISTER'}
    group_key: bpy.props.StringProperty()
    def execute(self, context):
        _toggle_open(context, self.group_key); return {"FINISHED"}


class WARDROBE_OT_select_item(bpy.types.Operator):
    bl_idname = "wardrobe.select_item"; bl_label = "Select"; bl_options = {'REGISTER'}
    blend_path: bpy.props.StringProperty()
    item_label: bpy.props.StringProperty()
    def execute(self, context):
        context.scene.wardrobe_selected_blend = self.blend_path
        context.scene.wardrobe_selected_label = self.item_label
        return {"FINISHED"}


class WARDROBE_OT_append_selected(bpy.types.Operator):
    bl_idname = "wardrobe.append_selected"; bl_label = "Append to Scene"
    bl_description = "Download .blend and append to scene"; bl_options = {'REGISTER'}
    def execute(self, context):
        repo_path = context.scene.wardrobe_selected_blend
        if not repo_path: self.report({"ERROR"}, "Nothing selected."); return {"CANCELLED"}
        rig_col = _rig_in_scene()
        ok, missing = _check_rig(rig_col)
        if not ok:
            self.report({"ERROR"}, f"Rig missing: {', '.join(missing)}. Append the rig first.")
            return {"CANCELLED"}
        def _base_name(n): return n.rsplit(".", 1)[0] if n.rsplit(".", 1)[-1].isdigit() else n
        arm = next((o for o in _collect_objects(rig_col) if _base_name(o.name) == ARMATURE), None)
        if not arm: self.report({"WARNING"}, f"'{ARMATURE}' not found — skipping armature wiring.")
        try:
            data = _fetch(f"{RAW_BASE}/{urllib.parse.quote(repo_path, safe='/')}")
        except Exception as e:
            self.report({"ERROR"}, f"Download failed: {e}"); return {"CANCELLED"}
        tmp = ""
        try:
            with tempfile.NamedTemporaryFile(suffix=".blend", delete=False) as f:
                f.write(data); tmp = f.name
            with bpy.data.libraries.load(tmp, link=False) as (src, dst):
                dst.collections = [c for c in src.collections if c in APPEND_MAP]
            moved = []
            for wrapper in dst.collections:
                if not wrapper: continue
                target_name = CLOTHING_COLS.get(wrapper.name, "")
                target = next((c for c in _all_children(rig_col)
                               if _base(c.name) == target_name), None) or rig_col
                for obj in _collect_objects(wrapper):
                    if obj.name not in {o.name for o in target.objects}: target.objects.link(obj)
                    if arm and obj.type == 'MESH':
                        for mod in obj.modifiers:
                            if mod.type == 'ARMATURE' and not mod.object: mod.object = arm
                    moved.append(obj.name)
                _remove_col(wrapper)
        finally:
            try: os.remove(tmp)
            except: pass
        if not moved: self.report({"WARNING"}, "No objects found."); return {"CANCELLED"}
        bpy.ops.ed.undo_push(message=f"Append {context.scene.wardrobe_selected_label}")
        self.report({"INFO"}, f"Added {len(moved)} object(s)" + (f" | Wired to {ARMATURE}" if arm else ""))
        return {"FINISHED"}



# ---------------------------------------------------------------------------
# Unity Export
# ---------------------------------------------------------------------------

def _get_cycles_devices():
    """Return device items matching Blender's Cycles preferences list."""
    items = [("CPU", "CPU", "Bake using CPU")]
    try:
        prefs = bpy.context.preferences.addons.get("cycles")
        if prefs:
            for dev in prefs.preferences.devices:
                if dev.type != "CPU":
                    safe_id = dev.name.replace(" ","_").replace("(","").replace(")","")
                    api = {"CUDA": " (CUDA)", "OPTIX": " (OptiX - faster)",
                           "HIP": " (HIP)", "METAL": " (Metal)"}.get(dev.type, "")
                    items.append((safe_id, dev.name + api, f"Bake using {dev.name}"))
    except Exception:
        pass
    return items


def _set_bake_device(device_id):
    scene = bpy.context.scene
    if device_id == "CPU":
        scene.cycles.device = "CPU"
    else:
        scene.cycles.device = "GPU"
        try:
            prefs = bpy.context.preferences.addons.get("cycles")
            if prefs:
                cprefs = prefs.preferences
                # Try each compute type until one has devices
                for compute_type in ("OPTIX", "CUDA", "HIP", "METAL", "ONEAPI"):
                    try:
                        cprefs.compute_device_type = compute_type
                        cprefs.refresh_devices()
                        if any(d.type != "CPU" for d in cprefs.devices):
                            break
                    except Exception:
                        continue
                for dev in cprefs.devices:
                    dev.use = True
        except Exception:
            pass


def _get_source_objects(body_type):
    """Return (bake_objects, reference_only_objects)."""
    bake_objs = []
    ref_objs  = []

    col_name = "FullBody" if body_type == "FB" else "BeanBody"
    col = bpy.data.collections.get(col_name)
    if col:
        bake_objs += [o for o in _collect_objects(col) if o.type == "MESH"]

    avatar_meshes = bpy.data.objects.get("Avatar_Meshes")
    if avatar_meshes:
        nose = next((c for c in avatar_meshes.children if c.name == "Nose_Meshes"), None)
        if nose:
            bake_objs += [o for o in nose.children_recursive if o.type == "MESH"]

    if body_type == "MB":
        fb_col = bpy.data.collections.get("FullBody")
        if fb_col:
            body_ref = next((o for o in _collect_objects(fb_col)
                             if o.type == "MESH" and o.name == "BodyMesh_LOD0"), None)
            if body_ref:
                ref_objs.append(body_ref)

    seen = set(); result = []
    for o in bake_objs:
        if o.name not in seen:
            seen.add(o.name); result.append(o)
    return result, ref_objs


def _ensure_bake_col(context):
    col = bpy.data.collections.get(BAKE_COL_NAME)
    if not col:
        col = bpy.data.collections.new(BAKE_COL_NAME)
        context.scene.collection.children.link(col)
    return col


def _apply_modifiers(obj, context):
    """Apply all non-armature modifiers, remove armature modifiers."""
    context.view_layer.objects.active = obj
    obj.select_set(True)
    for mod in list(obj.modifiers):
        if mod.type != "ARMATURE":
            try: bpy.ops.object.modifier_apply(modifier=mod.name)
            except: obj.modifiers.remove(mod)
    for mod in list(obj.modifiers):
        if mod.type == "ARMATURE": obj.modifiers.remove(mod)
    obj.select_set(False)


def _cleanup_export(bake_col):
    if not bake_col: return
    objs   = list(_collect_objects(bake_col))
    meshes = [o.data for o in objs if o.type == "MESH" and o.data]
    mats   = [m for o in objs if o.type == "MESH"
              for m in o.data.materials if m and "_bake" in m.name]
    images = [i for i in bpy.data.images if "_bake" in i.name]
    for obj in objs:
        for col in list(bpy.data.collections):
            if obj.name in {o.name for o in col.objects}: col.objects.unlink(obj)
        bpy.data.objects.remove(obj, do_unlink=True)
    for m in meshes:
        if m.users == 0: bpy.data.meshes.remove(m)
    for m in set(mats):
        if m.users == 0: bpy.data.materials.remove(m)
    for i in images: bpy.data.images.remove(i)
    _remove_col(bake_col)


class WARDROBE_OT_set_bake_device(bpy.types.Operator):
    bl_idname = "wardrobe.set_bake_device"; bl_label = "Set Bake Device"
    bl_options = {"REGISTER"}
    device_id: bpy.props.StringProperty()
    def execute(self, context):
        context.scene.wardrobe_bake_device = self.device_id
        return {"FINISHED"}


class WARDROBE_OT_export_unity(bpy.types.Operator):
    bl_idname      = "wardrobe.export_unity"
    bl_label       = "Export for Unity"
    bl_description = "Bake and export FBX for Unity"
    bl_options     = {"REGISTER"}

    body_type: bpy.props.EnumProperty(
        name="Body Type",
        items=[("FB", "Full Body (FB)", ""), ("MB", "Bean Body (MB)", "")],
        default="FB",
    )
    directory: bpy.props.StringProperty(subtype="DIR_PATH", default="")

    def invoke(self, context, event):
        self.body_type = context.scene.wardrobe_export_body
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        scene    = context.scene
        out_dir  = self.directory or tempfile.gettempdir()
        fbx_path = os.path.join(out_dir, "model.fbx")
        tex_dir  = os.path.join(out_dir, "textures")
        os.makedirs(tex_dir, exist_ok=True)

        # ── 1. Validate ───────────────────────────────────────────────────
        source_objs, ref_objs = _get_source_objects(self.body_type)
        if not source_objs:
            self.report({"ERROR"}, "No mesh objects found for selected body type.")
            return {"CANCELLED"}
        if not os.path.isfile(UNITY_RIG_FILE):
            self.report({"ERROR"}, "Rec_Room_Unity_Rig.blend not found in addon folder.")
            return {"CANCELLED"}

        # ── 2. Cycles + bake settings ─────────────────────────────────────
        prev_engine = scene.render.engine
        prev_device = scene.cycles.device
        scene.render.engine = "CYCLES"
        _set_bake_device(context.scene.wardrobe_bake_device)

        bk = scene.render.bake
        bk.use_selected_to_active = False
        bk.target                 = "IMAGE_TEXTURES"
        bk.use_clear              = True
        bk.margin                 = 16
        bk.margin_type            = "ADJACENT_FACES"
        bk.use_pass_direct        = False
        bk.use_pass_indirect      = False
        bk.use_pass_color         = True

        bake_col = _ensure_bake_col(context)
        pieces   = []  # (orig, bake_dup, is_ref)
        applied_temps = []  # temp objects with modifiers applied, to delete after

        # ── 3. Apply modifiers on temp copies first, then separate/duplicate
        # This ensures current pose/body shape is baked into the mesh data.
        for orig in source_objs:
            # Create a temp copy with all modifiers applied in current pose
            tmp = orig.copy()
            tmp.data = orig.data.copy()
            tmp.name = orig.name + "_tmp_applied"
            scene.collection.objects.link(tmp)
            context.view_layer.objects.active = tmp
            tmp.select_set(True)
            # Apply each modifier including armature (captures current pose)
            for mod in list(tmp.modifiers):
                try: bpy.ops.object.modifier_apply(modifier=mod.name)
                except: tmp.modifiers.remove(mod)
            tmp.select_set(False)
            applied_temps.append((orig, tmp))

        for orig, tmp in applied_temps:
            if len(tmp.data.materials) <= 1:
                dup = tmp.copy()
                dup.data = tmp.data.copy()
                dup.name = orig.name + "_bake"
                dup.data.materials.clear()
                for mat in tmp.data.materials:
                    dup.data.materials.append(mat.copy() if mat else None)
                bake_col.objects.link(dup)
                pieces.append((orig, dup, False))
            else:
                names_before = {o.name for o in bpy.data.objects if o.type == "MESH"}
                for o in context.scene.objects: o.select_set(False)
                context.view_layer.objects.active = tmp
                tmp.select_set(True)
                bpy.ops.object.mode_set(mode="EDIT")
                bpy.ops.mesh.separate(type="MATERIAL")
                bpy.ops.object.mode_set(mode="OBJECT")
                tmp_pieces = [o for o in bpy.data.objects
                              if o.type == "MESH" and
                              (o.name == tmp.name or o.name not in names_before)]
                self.report({"INFO"}, f"Separated {orig.name} into {len(tmp_pieces)} piece(s)")
                for tp in tmp_pieces:
                    dup = tp.copy()
                    dup.data = tp.data.copy()
                    dup.name = tp.name.replace("_tmp_applied", "") + "_bake"
                    dup.data.materials.clear()
                    for mat in tp.data.materials:
                        dup.data.materials.append(mat.copy() if mat else None)
                    bake_col.objects.link(dup)
                    pieces.append((orig, dup, False))
                # Remove the separated tmp pieces
                for tp in tmp_pieces:
                    bpy.data.objects.remove(tp, do_unlink=True)
                continue  # skip the normal tmp cleanup below for multi-mat

        # Clean up temp applied objects
        for orig, tmp in applied_temps:
            if tmp.name in bpy.data.objects:
                bpy.data.objects.remove(tmp, do_unlink=True)

        # ── 4. Smart UV Unwrap + assign bake materials + images ───────────
        piece_maps = {}
        for orig, dup, is_ref in pieces:
            if not dup.data.uv_layers:
                dup.data.uv_layers.new(name="UVMap")
            old_mat = dup.data.materials[0] if dup.data.materials else None
            new_mat = old_mat.copy() if old_mat else bpy.data.materials.new(dup.name + "_mat")
            new_mat.use_nodes = True
            dup.data.materials[0] = new_mat

            albedo_img = bpy.data.images.new(dup.name + "_albedo_bake",
                                              width=BAKE_RES, height=BAKE_RES, alpha=False)
            normal_img = bpy.data.images.new(dup.name + "_normal_bake",
                                              width=BAKE_RES, height=BAKE_RES, alpha=False)
            normal_img.colorspace_settings.name = "Non-Color"
            piece_maps[dup.name] = {"mat": new_mat, "albedo": albedo_img, "normal": normal_img}

        # ── 5. Bake directly from material (no selected-to-active) ─────────
        # Direct baking reads straight from shader nodes — no ray casting,
        # no artifacts from nearby geometry.
        for o in scene.objects: o.select_set(False)
        for orig, dup, _ in pieces:
            maps = piece_maps[dup.name]
            context.view_layer.objects.active = dup
            dup.select_set(True)

            _add_bake_image_node(maps["mat"], maps["albedo"])
            try: bpy.ops.object.bake(type="DIFFUSE"); self.report({"INFO"}, f"Albedo: {dup.name}")
            except Exception as e: self.report({"WARNING"}, f"Albedo failed {dup.name}: {e}")

            _add_bake_image_node(maps["mat"], maps["normal"])
            try: bpy.ops.object.bake(type="NORMAL"); self.report({"INFO"}, f"Normal: {dup.name}")
            except Exception as e: self.report({"WARNING"}, f"Normal failed {dup.name}: {e}")

            dup.select_set(False)

        # ── 6. Save textures to disk ──────────────────────────────────────
        for orig, dup, _ in pieces:
            maps = piece_maps[dup.name]
            for key, suffix in [("albedo", "_albedo.png"), ("normal", "_normal.png")]:
                img = maps[key]
                img.filepath_raw = os.path.join(tex_dir, dup.name + suffix)
                img.file_format  = "PNG"; img.save()
            _add_bake_image_node(maps["mat"], maps["albedo"])

        # ── 7. Append Unity rig into Bake collection ──────────────────────
        unity_arm = None
        with bpy.data.libraries.load(UNITY_RIG_FILE, link=False) as (df, dt):
            if UNITY_RIG_COL in df.collections:
                dt.collections = [UNITY_RIG_COL]
        for col in dt.collections:
            if col is None: continue
            if col.name not in {c.name for c in bake_col.children}:
                bake_col.children.link(col)
            for obj in _collect_objects(col):
                if obj.type == "ARMATURE":
                    unity_arm = obj; break

        if not unity_arm:
            self.report({"WARNING"}, f"'{UNITY_ARMATURE}' not found in Unity rig.")

        # ── 8. Add armature modifier to all bake pieces ───────────────────
        for orig, dup, _ in pieces:
            mod = dup.modifiers.new(name="Armature", type="ARMATURE")
            if unity_arm: mod.object = unity_arm

        # ── 9. Reference-only objects (BodyMesh_LOD0 for MB) ─────────────
        for ref in ref_objs:
            if unity_arm:
                mod = ref.modifiers.new(name="_unity_ref_arm", type="ARMATURE")
                mod.object = unity_arm

        # ── 10. Bone anchor mesh ──────────────────────────────────────────
        anchor_obj = None
        if unity_arm:
            anchor_mesh = bpy.data.meshes.new("_bone_anchor_mesh")
            anchor_mesh.from_pydata([(0.0, 0.0, 0.0)], [], [])
            anchor_mesh.update()
            anchor_obj = bpy.data.objects.new("_bone_anchor", anchor_mesh)
            bake_col.objects.link(anchor_obj)
            for bone in unity_arm.data.bones:
                vg = anchor_obj.vertex_groups.new(name=bone.name)
                vg.add([0], 1.0, "REPLACE")
            arm_mod = anchor_obj.modifiers.new(name="Armature", type="ARMATURE")
            arm_mod.object = unity_arm

        # ── 11. Export FBX ────────────────────────────────────────────────
        export_ok = False
        try:
            for o in scene.objects: o.select_set(False)
            for _, dup, _ in pieces: dup.select_set(True)
            for col in bake_col.children:
                for obj in _collect_objects(col): obj.select_set(True)
            if anchor_obj: anchor_obj.select_set(True)
            for ref in ref_objs: ref.select_set(True)

            bpy.ops.export_scene.fbx(
                filepath=fbx_path,
                use_selection=True,
                path_mode="COPY",
                embed_textures=False,
                bake_anim=False,
                mesh_smooth_type="FACE",
                add_leaf_bones=False,
                use_mesh_modifiers=True,
                armature_nodetype="ROOT",
                use_armature_deform_only=False,
                bake_space_transform=False,
            )
            export_ok = True
        except Exception as e:
            self.report({"ERROR"}, f"FBX export failed: {e}")
        finally:
            # Remove temp ref modifiers
            for ref in ref_objs:
                for mod in list(ref.modifiers):
                    if mod.name == "_unity_ref_arm": ref.modifiers.remove(mod)
            _cleanup_export(bake_col)
            scene.render.engine = prev_engine
            scene.cycles.device = prev_device

        if export_ok:
            self.report({"INFO"}, f"Exported model.fbx to {out_dir}")
            return {"FINISHED"}
        return {"CANCELLED"}

# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class WARDROBE_PT_main(bpy.types.Panel):
    bl_label = "Rec Room Wardrobe"; bl_idname = "WARDROBE_PT_main"
    bl_space_type = "VIEW_3D"; bl_region_type = "UI"; bl_category = "Wardrobe"

    def draw(self, context):
        layout, scene = self.layout, context.scene

        if not scene.wardrobe_enabled:
            col = layout.column(align=True)
            col.scale_y = 1.6
            col.operator("wardrobe.enable", text="Enable Wardrobe Browser", icon="PLAY")
            return

        box = layout.box()
        box.label(text="Rec Room Rig:", icon="ARMATURE_DATA")
        rig = _rig_in_scene()
        if rig:
            ok, missing = _check_rig(rig)
            row = box.row()
            row.alert = not ok
            row.label(text=f"{rig.name} ✓" if ok else f"Missing: {', '.join(missing)}",
                      icon="CHECKMARK" if ok else "ERROR")
            sub = box.row()
            sub.enabled = False
            sub.operator("wardrobe.append_rig", text="Rig already in scene", icon="ADD")
        else:
            box.operator("wardrobe.append_rig", text="Set Up Scene", icon="SCENE_DATA")

        layout.separator()

        box = layout.box()
        row = box.row(align=True)
        if INDEX_LOADING:
            row.label(text="Loading…", icon="TIME")
        elif INDEX_ERROR:
            row.alert = True; row.label(text=INDEX_ERROR, icon="ERROR"); row.alert = False
            box.operator("wardrobe.fetch_index", text="Retry", icon="FILE_REFRESH"); return
        elif INDEX_CACHE is None:
            row.label(text="Not loaded", icon="QUESTION")
            box.operator("wardrobe.fetch_index", text="Load from GitHub", icon="URL")
            fetch_index(); return
        else:
            row.label(text="Index loaded ✓", icon="CHECKMARK")
            row.operator("wardrobe.fetch_index", text="", icon="FILE_REFRESH")
            row.operator("wardrobe.clear_cache", text="", icon="TRASH")

        layout.separator()

        q = scene.wardrobe_search.strip()
        row = layout.row(align=True)
        row.prop(scene, "wardrobe_search", text="", icon="VIEWZOOM")
        if q: row.operator("wardrobe.clear_search", text="", icon="X")

        layout.separator()

        open_grps = _open_set(context)
        sel       = scene.wardrobe_selected_blend

        if q:
            results = search_items(q)
            layout.label(text=f'{len(flatten(results))} result(s):' if results else f'No results for "{q}"',
                         icon="VIEWZOOM" if results else "INFO")
            for item in results: self._item(layout, item, open_grps, sel)
        else:
            layout.prop(scene, "wardrobe_category", text="")
            layout.separator()
            for item in (INDEX_CACHE or {}).get(scene.wardrobe_category, []):
                self._item(layout, item, open_grps, sel)

        if sel:
            layout.separator()
            bar = layout.box()
            bar.label(text=scene.wardrobe_selected_label, icon="CHECKMARK")
            bar.operator("wardrobe.append_selected", icon="IMPORT")

        # ── Unity Export ──────────────────────────────────────────────────
        layout.separator()
        box = layout.box()
        box.label(text="Unity Export (Beta):", icon="EXPORT")
        box.prop(scene, "wardrobe_export_body", text="Body")
        box.prop(scene, "wardrobe_bake_device", text="Device")
        if scene.wardrobe_export_body == "MB":
            col = box.column(align=True)
            col.scale_y = 0.65
            col.label(text="Exports full body mesh with it,", icon="INFO")
            col.label(text="its a limitation of how unity handles")
            col.label(text="the rig. After its set to humanoid")
            col.label(text="and applied you should be able to")
            col.label(text="delete the FB mesh.")
        col2 = box.column(align=True)
        col2.scale_y = 0.65
        col2.label(text="FB & MB Clothing must be enabled", icon="ERROR")
        col2.label(text="in Rig UI for export to work.")
        box.operator("wardrobe.export_unity", text="Export for Unity", icon="EXPORT")

    def _item(self, layout, item, open_grps, sel):
        if item["children"]:  self._group(layout, item, open_grps, sel)
        elif item["blend"]:   self._leaf(layout, item, sel)

    def _group(self, layout, item, open_grps, sel):
        key = _safe_key(item["label"]); is_open = key in open_grps
        box = layout.box()
        op  = box.row().operator("wardrobe.toggle_group", text=item["label"],
                                  icon="TRIA_DOWN" if is_open else "TRIA_RIGHT", emboss=False)
        op.group_key = key
        if item["preview"]:
            ico = load_preview(item["preview"])
            if ico:
                box.template_icon(icon_value=ico, scale=5.0)
            else:
                _prefetch_single(item["preview"])
        if is_open:
            for child in item["children"]: self._leaf(box, child, sel)

    def _leaf(self, layout, item, sel):
        is_sel = item["blend"] == sel
        box = layout.box(); box.alert = is_sel
        row = box.row(align=True)
        if item["preview"]:
            ico = load_preview(item["preview"])
            if ico: row.template_icon(icon_value=ico, scale=4.0)
            else: row.label(icon="IMAGE_DATA", text="")
        else:
            row.label(icon="IMAGE_DATA", text="")
        col = row.column()
        col.label(text=item["label"])
        op = col.operator("wardrobe.select_item",
                          text="Selected ✓" if is_sel else "Select",
                          icon="RADIOBUT_ON" if is_sel else "RADIOBUT_OFF", depress=is_sel)
        op.blend_path = item["blend"]; op.item_label = item["label"]


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = [
    WardrobePreferences,
    WARDROBE_OT_clear_cache, WARDROBE_OT_enable, WARDROBE_OT_append_rig,
    WARDROBE_OT_fetch_index, WARDROBE_OT_clear_search,
    WARDROBE_OT_toggle_group, WARDROBE_OT_select_item, WARDROBE_OT_append_selected,
    WARDROBE_OT_set_bake_device, WARDROBE_OT_export_unity,
    WARDROBE_PT_main,
]

def register():
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.wardrobe_enabled        = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.wardrobe_category       = bpy.props.EnumProperty(name="Category", items=[(c,c,"") for c in CATEGORIES])
    bpy.types.Scene.wardrobe_search         = bpy.props.StringProperty(name="Search", default="")
    bpy.types.Scene.wardrobe_selected_blend = bpy.props.StringProperty(default="")
    bpy.types.Scene.wardrobe_selected_label = bpy.props.StringProperty(default="")
    bpy.types.Scene.wardrobe_open_groups    = bpy.props.StringProperty(default="")
    bpy.types.Scene.wardrobe_export_body    = bpy.props.EnumProperty(
        name="Body Type",
        items=[("FB","Full Body (FB)",""),("MB","Bean Body (MB)","")],
        default="FB",
    )
    bpy.types.Scene.wardrobe_bake_device    = bpy.props.EnumProperty(
        name="Bake Device",
        items=lambda self, ctx: _get_cycles_devices(),
    )

def unregister():
    global PREVIEW_COLL, INDEX_CACHE, INDEX_ERROR, INDEX_LOADING
    INDEX_CACHE = None; INDEX_ERROR = ""; INDEX_LOADING = False
    _reset_previews()
    _unload_rig_ui()
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except: pass
    for a in ["wardrobe_enabled","wardrobe_category","wardrobe_search",
              "wardrobe_selected_blend","wardrobe_selected_label","wardrobe_open_groups",
              "wardrobe_export_body","wardrobe_bake_device"]:
        try: delattr(bpy.types.Scene, a)
        except: pass

if __name__ == "__main__": register()
