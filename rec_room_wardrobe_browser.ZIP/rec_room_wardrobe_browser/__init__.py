bl_info = {
    "name": "Rec Room Wardrobe Browser",
    "author": "Headless Dull",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Wardrobe",
    "description": "Browse and append wardrobe items from GitHub",
    "category": "Object",
}

import bpy, bpy.utils.previews
import os, json, tempfile, threading, hashlib
import urllib.request, urllib.error, urllib.parse

# Rig UI

import importlib as _importlib, sys as _sys

def _load_rig_ui():
    mod_path = os.path.join(os.path.dirname(__file__), "rig_ui_patch.py")
    spec = _importlib.util.spec_from_file_location("rig_ui_patch", mod_path)
    mod  = _importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _sys.modules["rig_ui_patch"] = mod
    mod.register_rig_ui()

def _unload_rig_ui():
    mod = _sys.modules.get("rig_ui_patch")
    if mod:
        try: mod.unregister_rig_ui()
        except: pass
        _sys.modules.pop("rig_ui_patch", None)

# Config

REPO          = "HeadlessDull/RecRoom-Avatar-Archive"
RAW_BASE      = f"https://raw.githubusercontent.com/{REPO}/main"
CATEGORIES    = ["Belt","Ear","Eye","Face","Hair","Hat","Legs","Neck","Shirt","Shoes","Shoulder","Wrist"]
APPEND_MAP    = {"FB": "FB Clothing", "MB": "MB Clothing"}
ARMATURE      = "Avatar_Skeleton"
RIG_FILE      = os.path.join(os.path.dirname(__file__), "Rec_Room_Rig.blend")
RIG_COL       = "Rec Room Rig"
RIG_UI_SCRIPT = "Avatar_RigUI.py"
CLOTHING_COLS = {"FB": "FB Clothing", "MB": "MB Clothing"}

# State

INDEX_CACHE   = None
INDEX_ERROR   = ""
INDEX_LOADING = False
PREVIEW_COLL  = None

# Helpers

def _pat():
    a = bpy.context.preferences.addons.get(__name__)
    return a.preferences.github_pat.strip() if a else ""

def _fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "RRWardrobeBrowser"})
    if p := _pat(): req.add_header("Authorization", f"token {p}")
    with urllib.request.urlopen(req, timeout=30) as r: return r.read()

def _cache_dir():
    d = os.path.join(os.path.dirname(__file__), ".cache")
    os.makedirs(d, exist_ok=True)
    return d

def _preview_local(repo_path):
    return os.path.join(_cache_dir(), hashlib.md5(repo_path.encode()).hexdigest() + ".png")

def _download_preview(repo_path):
    if not repo_path: return
    local = _preview_local(repo_path)
    if os.path.isfile(local): return
    try: open(local, "wb").write(_fetch(f"{RAW_BASE}/{urllib.parse.quote(repo_path, safe='/')}"))
    except Exception: pass

def _get_preview(repo_path):
    if not repo_path: return ""
    local = _preview_local(repo_path)
    return local if os.path.isfile(local) else ""

def _prefetch_previews(items):
    from concurrent.futures import ThreadPoolExecutor
    paths = []
    for item in items:
        if item.get("preview"): paths.append(item["preview"])
        for child in item.get("children", []):
            if child.get("preview"): paths.append(child["preview"])
    if not paths: return
    def _dl_and_redraw(path):
        _download_preview(path)
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                if a.type == "VIEW_3D": a.tag_redraw()
    with ThreadPoolExecutor(max_workers=8) as ex:
        ex.map(_dl_and_redraw, paths)

def load_preview(repo_path):
    global PREVIEW_COLL
    if not repo_path: return 0
    local = _get_preview(repo_path)
    if not local: return 0
    if PREVIEW_COLL is None: PREVIEW_COLL = bpy.utils.previews.new()
    if local not in PREVIEW_COLL:
        try: PREVIEW_COLL.load(local, local, "IMAGE")
        except: return 0
    return PREVIEW_COLL[local].icon_id

def _load_index_bg():
    global INDEX_CACHE, INDEX_ERROR, INDEX_LOADING
    try:
        INDEX_CACHE = json.loads(_fetch(f"{RAW_BASE}/index.json"))
        all_prev = [i for cat in CATEGORIES for i in INDEX_CACHE.get(cat, [])]
        threading.Thread(target=_prefetch_previews, args=(all_prev,), daemon=True).start()
    except urllib.error.HTTPError as e:
        INDEX_ERROR = ("Auth failed — check PAT in preferences." if e.code == 401 else
                       "index.json not found — run build_index.py." if e.code == 404 else
                       f"HTTP {e.code}: {e.reason}")
    except Exception as e:
        INDEX_ERROR = str(e)
    finally:
        INDEX_LOADING = False
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                if a.type == "VIEW_3D": a.tag_redraw()

def fetch_index():
    global INDEX_LOADING
    if INDEX_CACHE or INDEX_LOADING: return
    INDEX_LOADING = True
    threading.Thread(target=_load_index_bg, daemon=True).start()

def all_items():
    if not INDEX_CACHE: return []
    return [i for cat in CATEGORIES for i in INDEX_CACHE.get(cat, [])]

def search_items(q):
    q = q.lower()
    out = []
    for item in all_items():
        if item["children"]:
            matched = [c for c in item["children"] if q in c["label"].lower()]
            out.append({**item, "children": matched} if matched
                       else item if q in item["label"].lower() else None)
        elif item["blend"] and q in item["label"].lower():
            out.append(item)
    return [x for x in out if x]

def flatten(items):
    return [i for item in items
            for i in (flatten(item["children"]) if item["children"] else [item] if item["blend"] else [])]

def _open_set(ctx):
    return set(x for x in ctx.scene.wardrobe_open_groups.split(",") if x)

def _toggle_open(ctx, key):
    s = _open_set(ctx)
    s.discard(key) if key in s else s.add(key)
    ctx.scene.wardrobe_open_groups = ",".join(s)

def _safe_key(label):
    return "".join(c if c.isalnum() else "_" for c in label).lower()

def _collect_objects(col):
    return list(col.objects) + [o for c in col.children for o in _collect_objects(c)]

def _remove_col(col):
    for c in list(col.children): _remove_col(c)
    for c in list(bpy.data.collections):
        if col.name in {x.name for x in c.children}: c.children.unlink(col)
    for s in bpy.data.scenes:
        if col.name in {x.name for x in s.collection.children}: s.collection.children.unlink(col)
    bpy.data.collections.remove(col)

def _base(name):
    """Strip .001 / .002 numeric suffix for name comparisons."""
    parts = name.rsplit(".", 1)
    return parts[0] if len(parts) == 2 and parts[1].isdigit() else name

def _all_children(col):
    for c in col.children:
        yield c
        yield from _all_children(c)

def _rig_in_scene():
    """Return the Rec Room Rig collection if it exists in the scene, else None."""
    for c in bpy.data.collections:
        if (_base(c.name) == RIG_COL and
                any(c.name in {x.name for x in s.collection.children}
                    for s in bpy.data.scenes)):
            return c
    return None

def _check_rig(col):
    """Returns (ok, missing_list) for a rig collection."""
    if not col: return False, [RIG_COL]
    child_base_names = {_base(c.name) for c in _all_children(col)}
    missing = [req for req in CLOTHING_COLS.values() if req not in child_base_names]
    if ARMATURE not in {_base(o.name) for o in _collect_objects(col)}: missing.append(ARMATURE)
    return len(missing) == 0, missing

# Preferences

class WardrobePreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    github_pat: bpy.props.StringProperty(name="GitHub PAT", default="", subtype="PASSWORD",
        description="Token for private repo — leave blank when repo is public")
    def draw(self, context):
        self.layout.prop(self, "github_pat")
        self.layout.label(text="Developer Setting", icon="INFO")

# Operators

class WARDROBE_OT_enable(bpy.types.Operator):
    bl_idname = "wardrobe.enable"; bl_label = "Enable Wardrobe Browser"
    bl_description = "Enable the wardrobe browser"; bl_options = {'REGISTER'}
    def execute(self, context):
        context.scene.wardrobe_enabled = True
        fetch_index()
        return {"FINISHED"}


class WARDROBE_OT_append_rig(bpy.types.Operator):
    bl_idname = "wardrobe.append_rig"; bl_label = "Append Rec Room Rig"
    bl_description = "Append the Rec Room Rig into the scene"; bl_options = {'REGISTER'}
    def execute(self, context):
        if not os.path.isfile(RIG_FILE):
            self.report({"ERROR"}, "Rec_Room_Rig.blend not found inside addon folder.")
            return {"CANCELLED"}

        with bpy.data.libraries.load(RIG_FILE, link=False) as (data_from, data_to):
            if RIG_COL not in data_from.collections:
                self.report({"ERROR"}, f"'{RIG_COL}' not found in rig blend.")
                return {"CANCELLED"}
            data_to.collections = [RIG_COL]
            data_to.texts = [t for t in data_from.texts if t == RIG_UI_SCRIPT]

        appended_col = None
        for col in data_to.collections:
            if col is None: continue
            if col.name not in {c.name for c in context.scene.collection.children}:
                context.scene.collection.children.link(col)
            appended_col = col

        try:
            _load_rig_ui()
        except Exception as e:
            self.report({"WARNING"}, f"Rig UI load warning: {e}")

        bpy.ops.ed.undo_push(message="Append Rec Room Rig")
        self.report({"INFO"}, f"Appended: {appended_col.name if appended_col else RIG_COL}")
        return {"FINISHED"}


class WARDROBE_OT_fetch_index(bpy.types.Operator):
    bl_idname = "wardrobe.fetch_index"; bl_label = "Refresh Index"
    bl_description = "Re-download index.json from GitHub"; bl_options = {'REGISTER'}
    def execute(self, context):
        global INDEX_CACHE, INDEX_ERROR, PREVIEW_COLL
        INDEX_CACHE = None; INDEX_ERROR = ""
        if PREVIEW_COLL: bpy.utils.previews.remove(PREVIEW_COLL); PREVIEW_COLL = None
        fetch_index(); self.report({"INFO"}, "Fetching index…"); return {"FINISHED"}


class WARDROBE_OT_clear_search(bpy.types.Operator):
    bl_idname = "wardrobe.clear_search"; bl_label = "Clear Search"; bl_options = {'REGISTER'}
    def execute(self, context):
        context.scene.wardrobe_search = ""; return {"FINISHED"}


class WARDROBE_OT_toggle_group(bpy.types.Operator):
    bl_idname = "wardrobe.toggle_group"; bl_label = "Toggle Group"; bl_options = {'REGISTER'}
    group_key: bpy.props.StringProperty()
    def execute(self, context):
        _toggle_open(context, self.group_key); return {"FINISHED"}


class WARDROBE_OT_select_item(bpy.types.Operator):
    bl_idname = "wardrobe.select_item"; bl_label = "Select"; bl_options = {'REGISTER'}
    blend_path: bpy.props.StringProperty()
    item_label: bpy.props.StringProperty()
    def execute(self, context):
        context.scene.wardrobe_selected_blend = self.blend_path
        context.scene.wardrobe_selected_label = self.item_label
        return {"FINISHED"}


class WARDROBE_OT_append_selected(bpy.types.Operator):
    bl_idname = "wardrobe.append_selected"; bl_label = "Append to Scene"
    bl_description = "Download .blend and append to scene"; bl_options = {'REGISTER'}
    def execute(self, context):
        repo_path = context.scene.wardrobe_selected_blend
        if not repo_path: self.report({"ERROR"}, "Nothing selected."); return {"CANCELLED"}

        rig_col = _rig_in_scene()
        ok, missing = _check_rig(rig_col)
        if not ok:
            self.report({"ERROR"}, f"Rig missing: {', '.join(missing)}. Append the rig first.")
            return {"CANCELLED"}

        def _base_name(n): return n.rsplit(".", 1)[0] if n.rsplit(".", 1)[-1].isdigit() else n
        arm = next((o for o in _collect_objects(rig_col) if _base_name(o.name) == ARMATURE), None)
        if not arm: self.report({"WARNING"}, f"'{ARMATURE}' not found — skipping armature wiring.")

        try:
            data = _fetch(f"{RAW_BASE}/{urllib.parse.quote(repo_path, safe='/')}")
        except Exception as e:
            self.report({"ERROR"}, f"Download failed: {e}"); return {"CANCELLED"}

        tmp = ""
        try:
            with tempfile.NamedTemporaryFile(suffix=".blend", delete=False) as f:
                f.write(data); tmp = f.name
            with bpy.data.libraries.load(tmp, link=False) as (src, dst):
                dst.collections = [c for c in src.collections if c in APPEND_MAP]
            moved = []
            for wrapper in dst.collections:
                if not wrapper: continue
                target_name = CLOTHING_COLS.get(wrapper.name, "")
                target = next((c for c in _all_children(rig_col)
                               if _base(c.name) == target_name), None) or rig_col
                for obj in _collect_objects(wrapper):
                    if obj.name not in {o.name for o in target.objects}: target.objects.link(obj)
                    if arm and obj.type == 'MESH':
                        for mod in obj.modifiers:
                            if mod.type == 'ARMATURE' and not mod.object: mod.object = arm
                    moved.append(obj.name)
                _remove_col(wrapper)
        finally:
            try: os.remove(tmp)
            except: pass

        if not moved: self.report({"WARNING"}, "No objects found."); return {"CANCELLED"}
        bpy.ops.ed.undo_push(message=f"Append {context.scene.wardrobe_selected_label}")
        self.report({"INFO"}, f"Added {len(moved)} object(s)" + (f" | Wired to {ARMATURE}" if arm else ""))
        return {"FINISHED"}

# Panel

class WARDROBE_PT_main(bpy.types.Panel):
    bl_label = "Rec Room Wardrobe"; bl_idname = "WARDROBE_PT_main"
    bl_space_type = "VIEW_3D"; bl_region_type = "UI"; bl_category = "Wardrobe"

    def draw(self, context):
        layout, scene = self.layout, context.scene

        if not scene.wardrobe_enabled:
            col = layout.column(align=True)
            col.scale_y = 1.6
            col.operator("wardrobe.enable", text="Enable Wardrobe Browser", icon="PLAY")
            return

        box = layout.box()
        box.label(text="Rec Room Rig:", icon="ARMATURE_DATA")

        rig = _rig_in_scene()
        if rig:
            # Rig exists — show status, disable append button
            ok, missing = _check_rig(rig)
            row = box.row()
            row.alert = not ok
            row.label(text=f"{rig.name} ✓" if ok else f"Missing: {', '.join(missing)}",
                      icon="CHECKMARK" if ok else "ERROR")
            sub = box.row()
            sub.enabled = False
            sub.operator("wardrobe.append_rig", text="Rig already in scene", icon="ADD")
        else:
            # No rig — show active append button
            box.operator("wardrobe.append_rig", text="Append Rec Room Rig", icon="ADD")

        layout.separator()

        box = layout.box()
        row = box.row(align=True)
        if INDEX_LOADING:
            row.label(text="Loading…", icon="TIME")
        elif INDEX_ERROR:
            row.alert = True; row.label(text=INDEX_ERROR, icon="ERROR"); row.alert = False
            box.operator("wardrobe.fetch_index", text="Retry", icon="FILE_REFRESH"); return
        elif INDEX_CACHE is None:
            row.label(text="Not loaded", icon="QUESTION")
            box.operator("wardrobe.fetch_index", text="Load from GitHub", icon="URL")
            fetch_index(); return
        else:
            row.label(text="Index loaded ✓", icon="CHECKMARK")
            row.operator("wardrobe.fetch_index", text="", icon="FILE_REFRESH")

        layout.separator()

        q = scene.wardrobe_search.strip()
        row = layout.row(align=True)
        row.prop(scene, "wardrobe_search", text="", icon="VIEWZOOM")
        if q: row.operator("wardrobe.clear_search", text="", icon="X")

        layout.separator()

        open_grps = _open_set(context)
        sel       = scene.wardrobe_selected_blend

        if q:
            results = search_items(q)
            layout.label(text=f'{len(flatten(results))} result(s):' if results else f'No results for "{q}"',
                         icon="VIEWZOOM" if results else "INFO")
            for item in results: self._item(layout, item, open_grps, sel)
        else:
            layout.prop(scene, "wardrobe_category", text="")
            layout.separator()
            for item in (INDEX_CACHE or {}).get(scene.wardrobe_category, []):
                self._item(layout, item, open_grps, sel)

        if sel:
            layout.separator()
            bar = layout.box()
            bar.label(text=scene.wardrobe_selected_label, icon="CHECKMARK")
            bar.operator("wardrobe.append_selected", icon="IMPORT")

    def _item(self, layout, item, open_grps, sel):
        if item["children"]:  self._group(layout, item, open_grps, sel)
        elif item["blend"]:   self._leaf(layout, item, sel)

    def _group(self, layout, item, open_grps, sel):
        key = _safe_key(item["label"]); is_open = key in open_grps
        box = layout.box()
        op  = box.row().operator("wardrobe.toggle_group", text=item["label"],
                                  icon="TRIA_DOWN" if is_open else "TRIA_RIGHT", emboss=False)
        op.group_key = key
        if ico := load_preview(item["preview"]): box.template_icon(icon_value=ico, scale=5.0)
        if is_open:
            for child in item["children"]: self._leaf(box, child, sel)

    def _leaf(self, layout, item, sel):
        is_sel = item["blend"] == sel
        box = layout.box(); box.alert = is_sel
        row = box.row(align=True)
        if ico := load_preview(item["preview"]): row.template_icon(icon_value=ico, scale=4.0)
        else: row.label(icon="IMAGE_DATA", text="")
        col = row.column()
        col.label(text=item["label"])
        op = col.operator("wardrobe.select_item",
                          text="Selected ✓" if is_sel else "Select",
                          icon="RADIOBUT_ON" if is_sel else "RADIOBUT_OFF", depress=is_sel)
        op.blend_path = item["blend"]; op.item_label = item["label"]

# Registration

classes = [
    WardrobePreferences,
    WARDROBE_OT_enable, WARDROBE_OT_append_rig,
    WARDROBE_OT_fetch_index, WARDROBE_OT_clear_search,
    WARDROBE_OT_toggle_group, WARDROBE_OT_select_item, WARDROBE_OT_append_selected,
    WARDROBE_PT_main,
]

def register():
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.wardrobe_enabled        = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.wardrobe_category       = bpy.props.EnumProperty(name="Category", items=[(c,c,"") for c in CATEGORIES])
    bpy.types.Scene.wardrobe_search         = bpy.props.StringProperty(name="Search", default="")
    bpy.types.Scene.wardrobe_selected_blend = bpy.props.StringProperty(default="")
    bpy.types.Scene.wardrobe_selected_label = bpy.props.StringProperty(default="")
    bpy.types.Scene.wardrobe_open_groups    = bpy.props.StringProperty(default="")

def unregister():
    global PREVIEW_COLL, INDEX_CACHE, INDEX_ERROR, INDEX_LOADING
    INDEX_CACHE = None; INDEX_ERROR = ""; INDEX_LOADING = False
    if PREVIEW_COLL: bpy.utils.previews.remove(PREVIEW_COLL); PREVIEW_COLL = None
    _unload_rig_ui()
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except: pass
    for a in ["wardrobe_enabled","wardrobe_category","wardrobe_search",
              "wardrobe_selected_blend","wardrobe_selected_label","wardrobe_open_groups"]:
        try: delattr(bpy.types.Scene, a)
        except: pass

if __name__ == "__main__": register()
